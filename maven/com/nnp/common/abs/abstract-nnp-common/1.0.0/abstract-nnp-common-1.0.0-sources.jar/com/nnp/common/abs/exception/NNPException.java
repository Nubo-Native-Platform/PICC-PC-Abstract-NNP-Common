package com.nnp.common.abs.exception;

import lombok.Getter;

import java.io.Serial;

@Getter
public class NNPException extends RuntimeException {

	@Serial
    private static final long serialVersionUID = 1L;
	private final String errCd;
	private final String message;
	private final String debugErrMsg;

	public NNPException() {
		super();
        errCd = null;
        message = null;
        debugErrMsg = null;
	}

	public NNPException(NNPErrorCodes errCd) {
		super();
		this.errCd = String.valueOf(errCd.getCode());
		this.message = errCd.getMessage();
		this.debugErrMsg = errCd.getMessage();
	}

	public NNPException(NNPErrorCodes errCd, String detailErrMsg) {
		super();
		this.errCd = String.valueOf(errCd.getCode());
		this.message = errCd.getMessage();
		this.debugErrMsg = detailErrMsg;
	}

	public NNPException(NNPErrorCodes errCd, Throwable ex) {
		super(ex);
		this.errCd = String.valueOf(errCd.getCode());
		this.message = errCd.getMessage();
		this.debugErrMsg = ex.getLocalizedMessage();
	}
}
